package com.autocalc;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Bo tinh bieu thuc don gian: + - * / x va ngoac. */
public final class Calc {
    private final String s;
    private int pos = 0;

    private Calc(String s) {
        this.s = s;
    }

    /** Tra ve ket qua, hoac null neu bieu thuc loi / chia cho 0. */
    public static Double eval(String expr) {
        try {
            String e = expr.replace('\u00d7', '*').replace('\u00f7', '/')
                    .replace('x', '*').replace('X', '*')
                    .replace('\u2212', '-').replace('\u2013', '-');
            Calc c = new Calc(e);
            double v = c.parseExpr();
            c.skipWs();
            if (c.pos != c.s.length()) return null;
            if (Double.isNaN(v) || Double.isInfinite(v)) return null;
            return v;
        } catch (RuntimeException ex) {
            return null;
        }
    }

    /** 44.0 -> "44", 2.5 -> "2.5", 3.333 -> "3.33" */
    public static String format(double v) {
        if (Math.abs(v - Math.rint(v)) < 1e-9) {
            return Long.toString((long) Math.rint(v));
        }
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP)
                .stripTrailingZeros().toPlainString();
    }

    private void skipWs() {
        while (pos < s.length() && Character.isWhitespace(s.charAt(pos))) pos++;
    }

    private double parseExpr() {
        double v = parseTerm();
        while (true) {
            skipWs();
            if (pos >= s.length()) return v;
            char c = s.charAt(pos);
            if (c == '+') { pos++; v += parseTerm(); }
            else if (c == '-') { pos++; v -= parseTerm(); }
            else return v;
        }
    }

    private double parseTerm() {
        double v = parseFactor();
        while (true) {
            skipWs();
            if (pos >= s.length()) return v;
            char c = s.charAt(pos);
            if (c == '*') { pos++; v *= parseFactor(); }
            else if (c == '/') { pos++; v /= parseFactor(); }
            else return v;
        }
    }

    private double parseFactor() {
        skipWs();
        if (pos >= s.length()) throw new IllegalArgumentException("eof");
        char c = s.charAt(pos);
        if (c == '-') { pos++; return -parseFactor(); }
        if (c == '+') { pos++; return parseFactor(); }
        if (c == '(') {
            pos++;
            double v = parseExpr();
            skipWs();
            if (pos >= s.length() || s.charAt(pos) != ')') throw new IllegalArgumentException("paren");
            pos++;
            return v;
        }
        int start = pos;
        while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) pos++;
        if (start == pos) throw new IllegalArgumentException("num");
        return Double.parseDouble(s.substring(start, pos));
    }
}
