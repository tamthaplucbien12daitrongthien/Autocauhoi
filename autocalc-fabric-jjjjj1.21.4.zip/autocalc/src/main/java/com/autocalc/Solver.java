package com.autocalc;

import java.io.BufferedReader;
import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bo giai cau hoi chat nhanh (khong phu thuoc Minecraft de de test).
 * Ho tro: tinh nhanh, dem chu cai, dien tu con thieu (goi y), dich Viet -> Anh.
 */
public final class Solver {

    public static final class Result {
        /** Dung de chong gui trung. */
        public final String key;
        /** Dap an; null = khong giai duoc. */
        public final String answer;
        /** Dong thong bao hien o chat cua nguoi choi. */
        public final String note;

        Result(String key, String answer, String note) {
            this.key = key;
            this.answer = answer;
            this.note = note;
        }
    }

    // ky tu dau nhay (thuong + cong)
    private static final String Q = "['\"\u2018\u2019\u201C\u201D`\u00B4]";
    private static final String NQ = "[^'\"\u2018\u2019\u201C\u201D`\u00B4\\n]";

    private static final Pattern MATH =
            Pattern.compile("([\\d(][\\d\\s+\\-*/\\u00d7\\u00f7xX().]*?)\\s*=\\s*\\?");

    private static final Pattern COUNT_QUOTED = Pattern.compile(
            Q + "\\s*(" + NQ + "+?)\\s*" + Q + "[^\\n]*?co bao nhieu (?:chu cai|ky tu)");
    private static final Pattern COUNT_PLAIN = Pattern.compile(
            "ten tieng anh\\s+([^\\n]+?)\\s+co bao nhieu (?:chu cai|ky tu)");

    private static final Pattern FILL = Pattern.compile(
            "dien[^:\\n]*:\\s*([^\\n(]+?)\\s*(?:\\(\\s*goi y\\s*:\\s*([^)\\n]+?)\\s*\\))?\\s*$",
            Pattern.MULTILINE);

    private static final Pattern QUOTED = Pattern.compile(Q + "\\s*(" + NQ + "+?)\\s*" + Q);
    private static final Pattern OF_TERM = Pattern.compile(
            "(?:tieng anh|tieng viet) cua\\s+([^\\n?]+?)\\s+la gi");

    private static final String[] CLASSIFIERS = {
            "con", "cai", "khoi", "vien", "qua", "cay", "thanh", "mob", "loai", "vat pham"
    };

    private final Map<String, String> viToEn = new HashMap<>();
    private final Map<String, String> enToVi = new HashMap<>();
    private final Set<String> englishWords = new LinkedHashSet<>();

    // ------------------------------------------------------------ tu dien

    public void load(BufferedReader r, boolean override) throws IOException {
        String line;
        while ((line = r.readLine()) != null) {
            line = line.replace("\uFEFF", "").trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            if (line.startsWith("@")) {
                String en = line.substring(1).trim();
                if (!en.isEmpty()) englishWords.add(en);
                continue;
            }
            int eq = line.lastIndexOf('=');
            if (eq <= 0 || eq == line.length() - 1) continue;
            String en = line.substring(eq + 1).trim();
            for (String vi : line.substring(0, eq).split("\\|")) {
                add(vi.trim(), en, override);
            }
        }
    }

    public void add(String vi, String en, boolean override) {
        if (vi.isEmpty() || en.isEmpty()) return;
        viToEn.put(fold(vi), en);
        if (override) enToVi.put(fold(en), vi);
        else enToVi.putIfAbsent(fold(en), vi);
        englishWords.add(en);
    }

    /** Bo dau tieng Viet + chu thuong. */
    public static String fold(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        n = n.replace('\u0111', 'd').replace('\u0110', 'D');
        return n.toLowerCase(Locale.ROOT);
    }

    private static String clean(String t) {
        return fold(t).replaceAll("^[\\p{Punct}\\s]+|[\\p{Punct}\\s]+$", "");
    }

    private String lookupVi(String term) {
        String t = clean(term);
        String r = viToEn.get(t);
        if (r != null) return r;
        for (String p : CLASSIFIERS) {
            if (t.startsWith(p + " ")) {
                r = viToEn.get(t.substring(p.length() + 1).trim());
                if (r != null) return r;
            }
        }
        return null;
    }

    private String lookupEn(String term) {
        return enToVi.get(clean(term));
    }

    // ------------------------------------------------------------ giai

    /** Tra ve null neu tin nhan khong phai cau hoi. */
    public Result solve(String raw) {
        String f = fold(raw);
        if (!f.contains("cau hoi") && !f.contains("tinh nhanh")) return null;

        Result r = tryMath(raw);
        if (r == null) r = tryCount(f);
        if (r == null) r = tryFill(f);
        if (r == null) r = tryTranslate(f);
        if (r != null) return r;

        if (f.contains("cau hoi")) {
            String shown = f.length() > 70 ? f.substring(0, 70) : f;
            return new Result(f, null, "Chưa giải được: " + shown.replace('\n', ' '));
        }
        return null;
    }

    private Result tryMath(String raw) {
        String norm = raw.replace('\u2212', '-').replace('\u2013', '-').replace('\u2014', '-');
        Matcher m = MATH.matcher(norm);
        int from = 0;
        while (from < norm.length() && m.find(from)) {
            String expr = m.group(1).trim();
            Double v = Calc.eval(expr);
            if (v != null) {
                String ans = Calc.format(v);
                return new Result("math:" + expr, ans, expr + " = " + ans);
            }
            from = m.start() + 1;
        }
        return null;
    }

    private Result tryCount(String f) {
        Matcher m = COUNT_QUOTED.matcher(f);
        if (!m.find()) {
            m = COUNT_PLAIN.matcher(f);
            if (!m.find()) return null;
        }
        String word = m.group(1).trim();
        boolean withSpaces = f.contains("tinh ca khoang trang") || f.contains("co tinh khoang trang");
        int n = withSpaces ? word.length() : word.replaceAll("\\s+", "").length();
        String ans = Integer.toString(n);
        return new Result("count:" + word, ans, "'" + word + "' có " + ans + " chữ cái");
    }

    private Result tryFill(String f) {
        Matcher m = FILL.matcher(f);
        if (!m.find()) return null;
        String blank = m.group(1).trim();
        String hint = m.group(2) == null ? null : m.group(2).trim();
        if (!blank.contains(".") && !blank.contains("\u2026") && !blank.contains("_")) return null;

        Pattern bp = blankPattern(blank);

        if (hint != null) {
            String en = lookupVi(hint);
            if (en != null && bp.matcher(fold(en)).matches()) {
                return fillResult(blank, en);
            }
        }
        for (String en : englishWords) {
            if (bp.matcher(fold(en)).matches()) {
                return fillResult(blank, en);
            }
        }
        return new Result("fill:" + blank, null,
                "Chưa biết từ: " + blank + (hint != null ? " (gợi ý: " + hint + ")" : ""));
    }

    private Result fillResult(String blank, String en) {
        String ans = en.toUpperCase(Locale.ROOT);
        return new Result("fill:" + blank, ans, blank.toUpperCase(Locale.ROOT) + " → " + ans);
    }

    private static Pattern blankPattern(String blank) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < blank.length()) {
            char c = blank.charAt(i);
            if (c == '.' || c == '\u2026') {
                while (i < blank.length() && (blank.charAt(i) == '.' || blank.charAt(i) == '\u2026')) i++;
                sb.append(".+");
            } else if (c == '_') {
                int j = i;
                while (j < blank.length() && blank.charAt(j) == '_') j++;
                sb.append(".{").append(j - i).append('}');
                i = j;
            } else {
                sb.append(Pattern.quote(String.valueOf(c)));
                i++;
            }
        }
        return Pattern.compile("^" + sb + "$");
    }

    private Result tryTranslate(String f) {
        boolean toEn = f.contains("tieng anh");
        boolean toVi = f.contains("tieng viet");
        if (!toEn && !toVi) return null;

        String term = null;
        Matcher m = QUOTED.matcher(f);
        if (m.find()) term = m.group(1).trim();
        if (term == null) {
            Matcher o = OF_TERM.matcher(f);
            if (o.find()) term = o.group(1).trim();
        }
        if (term == null) return null;

        String ans = toEn ? lookupVi(term) : lookupEn(term);
        if (ans == null && toEn && toVi) ans = lookupEn(term);
        if (ans == null) {
            return new Result("tr:" + term, null,
                    "Chưa biết từ '" + term + "' — thêm bằng /autocalc add " + term + "=English");
        }
        return new Result("tr:" + term, ans, "'" + term + "' → " + ans);
    }
}
