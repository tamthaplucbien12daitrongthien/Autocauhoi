package com.autocalc;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class AutoCalcClient implements ClientModInitializer {

    /** Bat/tat mod. */
    public static boolean enabled = true;
    /** Do tre truoc khi gui dap an (tick, 20 tick = 1 giay). */
    public static int delayTicks = 10;

    private static final Solver SOLVER = new Solver();

    private static String pendingAnswer = null;
    private static int ticksLeft = 0;
    private static String lastKey = "";
    private static long lastTime = 0;

    @Override
    public void onInitializeClient() {
        loadDictionaries();

        ClientReceiveMessageEvents.GAME.register(AutoCalcClient::onGameMessage);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (pendingAnswer == null) return;
            if (--ticksLeft > 0) return;
            String answer = pendingAnswer;
            pendingAnswer = null;
            if (client.player != null && client.player.networkHandler != null) {
                client.player.networkHandler.sendChatMessage(answer);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("autocalc")
                        .executes(ctx -> {
                            enabled = !enabled;
                            ctx.getSource().sendFeedback(Text.literal(
                                    "[AutoCalc] " + (enabled ? "BẬT" : "TẮT")));
                            return 1;
                        })
                        .then(ClientCommandManager.literal("delay")
                                .then(ClientCommandManager.argument("ticks",
                                                IntegerArgumentType.integer(0, 200))
                                        .executes(ctx -> {
                                            delayTicks = IntegerArgumentType.getInteger(ctx, "ticks");
                                            ctx.getSource().sendFeedback(Text.literal(
                                                    "[AutoCalc] Độ trễ = " + delayTicks + " tick"));
                                            return 1;
                                        })))
                        .then(ClientCommandManager.literal("add")
                                .then(ClientCommandManager.argument("entry", StringArgumentType.greedyString())
                                        .executes(ctx -> {
                                            String entry = StringArgumentType.getString(ctx, "entry");
                                            int eq = entry.indexOf('=');
                                            if (eq <= 0 || eq == entry.length() - 1) {
                                                ctx.getSource().sendFeedback(Text.literal(
                                                        "[AutoCalc] Cú pháp: /autocalc add tiếng việt=English"));
                                                return 0;
                                            }
                                            String vi = entry.substring(0, eq).trim();
                                            String en = entry.substring(eq + 1).trim();
                                            SOLVER.add(vi, en, true);
                                            saveUserEntry(vi + "=" + en);
                                            ctx.getSource().sendFeedback(Text.literal(
                                                    "[AutoCalc] Đã thêm: " + vi + " → " + en));
                                            return 1;
                                        })))));
    }

    private static void onGameMessage(Text message, boolean overlay) {
        if (!enabled || overlay) return;

        Solver.Result r = SOLVER.solve(message.getString());
        if (r == null) return;

        long now = System.currentTimeMillis();
        if (r.key.equals(lastKey) && now - lastTime < 3000) return; // chong trung
        lastKey = r.key;
        lastTime = now;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("[AutoCalc] " + r.note), false);
        }
        if (r.answer != null) {
            pendingAnswer = r.answer;
            ticksLeft = Math.max(1, delayTicks);
        }
    }

    // ---- tu dien ----

    private static void loadDictionaries() {
        // 1) tu dien co san trong mod
        try (InputStream in = AutoCalcClient.class.getClassLoader()
                .getResourceAsStream("autocalc-dict.txt")) {
            if (in != null) {
                SOLVER.load(new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)), false);
            }
        } catch (Exception e) {
            System.err.println("[AutoCalc] Không đọc được tu dien co san: " + e);
        }
        // 2) tu dien cua ban: .minecraft/config/autocalc-dict.txt
        Path user = userDictPath();
        if (Files.exists(user)) {
            try (BufferedReader r = Files.newBufferedReader(user, StandardCharsets.UTF_8)) {
                SOLVER.load(r, true);
            } catch (Exception e) {
                System.err.println("[AutoCalc] Không đọc được " + user + ": " + e);
            }
        }
    }

    private static Path userDictPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("autocalc-dict.txt");
    }

    private static void saveUserEntry(String line) {
        try {
            Path p = userDictPath();
            Files.createDirectories(p.getParent());
            Files.writeString(p, line + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception e) {
            System.err.println("[AutoCalc] Không lưu được từ mới: " + e);
        }
    }
}
